<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>SPK Bimbel</title>

    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(url('assets/login/css/all')); ?>"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- CSS Files -->
    <link href="<?php echo e(url('assets/login/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('assets/login/css/now-ui-dashboard.minaa26.css?v=1.5.0')); ?>" rel="stylesheet" />
    
	<script src="<?php echo e(url('assets/js/sweetalert2.min.js')); ?>"></script>
    

</head>
<body class="login-page sidebar-mini">
    
        

        
    <?php echo $__env->yieldContent('content'); ?>

    <!--   Core JS Files   -->
    <script src="<?php echo e(url('assets/login/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/login/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/login/js/bootstrap.min.js')); ?>"></script>
    

    <!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(url('assets/login/js/demo.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            demo.checkFullPageBackgroundImage();
        });
    </script>

</body>
</html>
<?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\99%\90%\Example\resources\views/layouts/app.blade.php ENDPATH**/ ?>