<?php echo $__env->yieldContent('modal-content'); ?>
</div>
</div>
</div><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\Example\resources\views////layouts/modal-body.blade.php ENDPATH**/ ?>