<?php $__env->startSection('pwd', 'View'); ?>
<?php $__env->startSection('now', 'Kriteria'); ?>
<?php $__env->startSection('link-active-view', 'active'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('menu-view-kriteria', 'nav-item-expanded nav-item-open'); ?>
<?php $__env->startSection('menu-view', 'nav-item-expanded nav-item-open'); ?>

    <div class="container-fluid mt-2">
        <div class="row">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-header header-elements-inline">
                        <h5 class="card-title">Data Kriteria</h5>
                        <?php if(Auth::user()->level_user == 'Admin'): ?>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#adddata">Tambah Data</button>
                        <?php endif; ?>
                    </div>
                    
                    <?php if(session('tambah')): ?>
                        <?php echo $__env->make('../layouts/sweetalert/tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <?php if(session('hapus')): ?>
                        <?php echo $__env->make('../layouts/sweetalert/hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <?php if(session('update')): ?>
                        <?php echo $__env->make('../layouts/sweetalert/update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered table-hover datatable-highlight">
                                    <thead>
                                        <tr class="text-center">
                                            <th width="10px">No</th>
                                            <th>Nama Kriteria</th>
                                            <th>Tipe Kriteria</th>
                                            <th>Bobot Kriteria</th>
                                            <?php if(auth()->user()->level_user == 'Admin'): ?>
                                            <th class="text-center">Actions</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($kriteria->nama_kriteria); ?></td>
                                                <td><?php echo e($kriteria->tipe_kriteria); ?></td>
                                                <td><?php echo e($kriteria->bobot_kriteria); ?></td>
                                                <?php if(auth()->user()->level_user == 'Admin'): ?>
                                                <td class="text-center">
                                                    <button class="btn btn-primary" data-toggle="modal" data-target="#updatedata<?php echo e($kriteria->id); ?>"><i class="fas fa-edit mr-3 fa-1x"></i>Ubah</button>
                                                    <button class="btn btn-warning" data-toggle="modal" data-target="#deletedata<?php echo e($kriteria->id); ?>"><i class="fas fa-trash-alt mr-3 fa-1x"></i>Hapus</button>
                                                </td>
                                                <?php endif; ?>
                                            </tr>

                                            
                                            <div class="container">
                                                <div class="modal fade" id="updatedata<?php echo e($kriteria->id); ?>" role="dialog">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">Update Kriteria</h4>
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            </div>
                                                        <div class="modal-body">
                                                            <form action="/update/kriteria/<?php echo e($kriteria->id); ?>" method="POST">
                                                                <?php echo e(csrf_field()); ?>

                                                                <div class="form-group">
                                                                    <label for="nama_kriteria" class="control-label">Nama Kriteria</label>
                                                                    <input type="text" name="nama_kriteria" id="nama_kriteria" class="form-control" value="<?php echo e($kriteria->nama_kriteria); ?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="tipe_kriteria" class="control-label">Tipe Kriteria</label>
                                                                    <select name="tipe_kriteria" id="tipe_kriteria" class="form-control">
                                                                        <option <?php echo e($kriteria->tipe_kriteria == 'Benefit' ? 'selected' : ''); ?> value="Benefit">Benefit</option>
                                                                        <option <?php echo e($kriteria->tipe_kriteria == 'Cost' ? 'selected' : ''); ?> value="Cost">Cost</option>
                                                                    </select>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="bobot_kriteria" class="control-label">Bobot Kriteria</label>
                                                                    <input type="number" name="bobot_kriteria" id="bobot_kriteria" class="form-control" value="<?php echo e($kriteria->bobot_kriteria); ?>">
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-success btn-lg">Update</button>
                                                        </div>
                                                    </form>
                                                    </div>
                                                </div>
                                            </div>
                                            

                                            
                                            <div class="modal fade" id="deletedata<?php echo e($kriteria->id); ?>" role="dialog">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Delete Kriteria</h4>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        </div>
                                                    <div class="modal-body">
                                                        
                                                        <center><h2>Hapus Data ?</h1></center>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <a href="/delete/kriteria/<?php echo e($kriteria->id); ?>">
                                                            <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                            <button type="button" class="btn btn-warning btn-lg">Hapus</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>

                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            
                            <div class="modal fade" id="adddata" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Tambah Alternatif</h4>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <form action="/kriteria" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="nama_alternayif">Nama Kriteria</label>
                                                    <input type="text" class="form-control" name="nama_kriteria" id="nama_kriteria" required autocomplete="off">
                                                </div>
                                                <div class="form-group">
                                                    <label for="tipe_kriteria">Tipe Kriteria</label>
                                                    <select name="tipe_kriteria" id="tipe_kriteria" class="form-control <?php if ($errors->has('tipe_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipe_kriteria'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                                        <option value="Benefit">Benefit</option>
                                                        <option value="Cost">Cost</option>
                                                    </select>
                                                    <?php if ($errors->has('nama_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_kriteria'); ?>
                                                        <div class="invalid-feedback">
                                                            <?php echo e($message); ?>

                                                        </div>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bobot">Bobot</label>
                                                    <input type="number" class="form-control <?php if ($errors->has('bobot_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bobot_kriteria'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autofocus autocomplete="bobot_kriteria" placeholder="masukkan bobot kriteria" name="bobot_kriteria">
                                                    <?php if ($errors->has('bobot_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bobot_kriteria'); ?>
                                                        <div class="invalid-feedback">
                                                            <?php echo e($message); ?>

                                                        </div>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-success btn-lg">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\90%\Example\resources\views/admin/view/kriteria.blade.php ENDPATH**/ ?>