<div class="modal fade" id="<?php echo $__env->yieldContent('modal-id'); ?>" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo $__env->yieldContent('modal-title'); ?></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
        <div class="modal-body">
<?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\Example\resources\views////layouts/modal.blade.php ENDPATH**/ ?>