<?php $__env->startSection('pwd', 'View'); ?>

<?php $__env->startSection('url', url('/view/pengguna') ); ?>

<?php $__env->startSection('icon', 'icon-user'); ?>

<?php $__env->startSection('now', 'Pengguna'); ?>

<?php $__env->startSection('view', 'active'); ?>
<?php $__env->startSection('menu-view-pengguna', 'nav-item-expanded nav-item-open'); ?>
<?php $__env->startSection('menu-view', 'nav-item-expanded nav-item-open'); ?>
<?php $__env->startSection('link-active-pengguna', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid mt-2">
        <div class="card">
            <div class="card-header header-elements-inline">
                <h5 class="card-title">Data Pengguna</h5>
            </div>
            
            <?php if(session('hapus')): ?>
                <?php echo $__env->make('../layouts/sweetalert/hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(session('update')): ?>
                <?php echo $__env->make('../layouts/sweetalert/update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="card-body">

                <div class="row">
                        <div class="col-md-11"></div>
                        <div class="col-md-1">
                            <a href="<?php echo e(url('insert/pengguna')); ?>">
                                <button type="button" class="btn btn-success">+ | Add Data</button>
                            </a>
                        </div>
                    </div>
                <table class="table table-bordered table-hover datatable-highlight">
						<thead>
							<tr>
								<th>No</th>
								<th>User Id</th>
								<th>Nama Pengguna</th>
								<th>Username</th>
								<th>Level</th>
								<th class="text-center">Actions</th>
							</tr>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($user->id); ?></td>
                                    <td>
                                        <?php if($user->level_user == 'Admin'): ?>
                                            <?php echo e($user->admin['nama_admin']); ?>

                                        <?php else: ?>
                                            <?php echo e($user->calonSiswa['nama_calonSiswa']); ?>

                                        <?php endif; ?>
                                        
                                    </td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->level_user); ?></td>
                                    <td class="text-center">
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#editdata<?php echo e($user->id); ?>"><i class="fas fa-edit mr-3 fa-1x"></i>Ubah</button>
                                        <button class="btn btn-warning" data-toggle="modal" data-target="#deletedata<?php echo e($user->id); ?>"><i class="fas fa-trash-alt mr-3 fa-1x"></i>Hapus</button>
                                    </td>
                                </tr>

                                
                                <div class="modal fade" id="editdata<?php echo e($user->id); ?>" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Update Pengguna</h4>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <form action="/update/pengguna/<?php echo e($user->id); ?>" method="POST">
                                                <?php echo e(@csrf_field()); ?>

                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="nama">Nama</label>
                                                        <input type="text" id="nama" name="nama" class="form-control" required value="<?php echo e($user->level_user == 'Admin' ? $user->admin['nama_admin'] : $user->calonSiswa['nama_calonSiswa']); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="level">Level</label>
                                                        <select name="level" id="level" class="form-control">
                                                            <option value="Admin" <?php echo e($user->level_user == 'Admin' ? 'selected' : ''); ?>>Admin</option>
                                                            <option value="Calon Siswa" <?php echo e($user->level_user == 'Calon Siswa' ? 'selected' : ''); ?>>Calon Siswa</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-warning btn-lg">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                


                                
                                <div class="modal fade" id="deletedata<?php echo e($user->id); ?>" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Pengguna</h4>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                        <div class="modal-body">
                                            <center><h2>Hapus Data ?</h1></center>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="/delete/pengguna/<?php echo e($user->id); ?>">
                                                <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                <button type="button" class="btn btn-warning btn-lg">Hapus</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                

                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\90%\Example\resources\views/admin/view/pengguna.blade.php ENDPATH**/ ?>