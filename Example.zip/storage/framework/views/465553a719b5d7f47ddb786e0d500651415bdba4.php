<?php echo e($slot); ?>

<?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\Fix\Example\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>