<?php $__env->startSection('pwd', 'Insert'); ?>

<?php $__env->startSection('url', url('/perhitungan') ); ?>

<?php $__env->startSection('icon', 'icon-user'); ?>

<?php $__env->startSection('now', 'Perhitungan'); ?>

<?php $__env->startSection('link-active-perhitungan', 'active'); ?>
<?php $__env->startSection('menu-perhitungan', 'nav-item-expanded nav-item-open'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid mt-2">
        <div class="card">
            <div class="card-header">
                <h3>Hasil Analisa</h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr class="text-center">
                            <th>Nama</th>
                            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($krit['nama_kriteria']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($al['nama_alternatif']); ?></td>
                                <?php $__currentLoopData = $al->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($nilai['nilai'] == "3" ? "Baik" : ($nilai['nilai'] == "2" ? "Sedang" : "Buruk")); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <table class="table table-bordered mt-2">
                    <thead>
                        <tr class="text-center">
                            <th>Nama</th>
                            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($krit['nama_kriteria']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($al['nama_alternatif']); ?></td>
                                <?php $__currentLoopData = $al->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php echo e($nilai['nilai']); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
        </div>

       

        
        <div class="card">
            <div class="card-header">
                <h3 class="float-left">Normalisasi</h3>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center">Nama</th>
                                <?php $bobot = [] ?>
                                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $bobot[$krit->id] = $krit->bobot_kriteria ?>
                                    <th class="text-center"><?php echo e($krit->nama_kriteria); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $rangking = []; ?>
                            <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($al->nama_alternatif); ?></td>
                                    <?php $total = 0;?>
                                    <?php $__currentLoopData = $al->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($crip->kriteria->tipe_kriteria == 'Cost'): ?>
                                            <?php $normalisasi = ($kode_krit[$crip->kriteria->id]/$crip->nilai); ?>
                                        <?php elseif($crip->kriteria->tipe_kriteria == 'Benefit'): ?>
                                            <?php $normalisasi = ($crip->nilai/$kode_krit[$crip->kriteria->id]); ?>
                                        <?php endif; ?>
                                            <?php $total = $total+($bobot[$crip->kriteria->id]*$normalisasi);?>
                                            <td><?php echo e($normalisasi); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $ranking[] = [
                                        // 'kode'  => $al->kode_alternatif,
                                        'nama'  => $al->nama_alternatif,
                                        'total' => $total
                                    ]; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        
        <div class="card">
            <div class="card-header">
                <h2>Ranking</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr class="text-center">
                                <th>Nama</th>
                                <th>Total</th>
                                <th>Ranking</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                // usort($ranking, function($a, $b) {
                                //     return $a['total']<=>$b['total'];
                                // });
                                // rsort($ranking);
                                // $a = 1;

                                usort($ranking, function($a, $b) {
                                    if($a['total']==$b['total']) return 0;
                                    return $a['total'] < $b['total'];
                                });
                                // rsort($ranking);
                                $a = 1;
                            ?>
                            <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($posisi['nama']); ?></td>
                                    <td><?php echo e($posisi['total']); ?></td>
                                    <td><?php echo e($a++); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\Example\resources\views/admin/view/perhitungan.blade.php ENDPATH**/ ?>