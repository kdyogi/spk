<?php $__env->startSection('pwd', 'Home'); ?>
<?php $__env->startSection('now', 'Dashboard'); ?>
<?php $__env->startSection('dashboard', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('fUpdate')): ?>
        <?php echo $__env->make('../layouts/sweetalert/gagal/update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <div class="container-fluid mt-2">
        <h1><strong>SELAMAT DATANG</strong></h1>
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="<?php echo e(Auth::user()->level_user == "Admin" ? 'col-md-4' : 'col-md-4'); ?>">
                                <a href="<?php echo e(url('view/kriteria')); ?>">
                                    <div class="card bg-indigo-400">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <strong><h1><?php echo e($kriteria); ?></h1></strong>
                                                    Jumlah Data Kriteria
                                                </div>
                                                <div class="col-md-3">
                                                    <span class="fa fa-book-open fa-5x"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                        </div>
                                    </div>
                                </a>
                            </div>
        
                            <?php if(Auth::user()->level_user == "Admin"): ?>
                                <div class="<?php echo e(Auth::user()->level_user == "Admin" ? 'col-md-4' : 'col-md-6'); ?>">
                                    <a href="<?php echo e(url('view/alternatif')); ?>">
                                        <div class="card bg-green-400">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <strong><h1><?php echo e($alternatif); ?></h1></strong>
                                                        Jumlah Data Alternatif Default
                                                    </div>
                                                    <div class="col-md-3">
                                                        <span class="fa fa-book fa-5x"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php elseif(Auth::user()->level_user == "Calon Siswa"): ?>
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <a href="<?php echo e(url('view/alternatif/user')); ?>">
                                                <div class="card bg-danger-400">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-9">
                                                                <strong><h1><?php echo e($countAlter); ?></h1></strong>
                                                                Jumlah Data Alternatif Siswa
                                                            </div>
                                                            <div class="col-md-3">
                                                                <span class="fa fa-book fa-5x"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-footer">
                                                        <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                                    </div>
                                                </div>
                                            </a>
        
                                        </div>
                                        <div class="col-md-6">
                                            <a href="<?php echo e(url('view/alternatif')); ?>">
                                                <div class="card bg-green-400">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-9">
                                                                <strong><h1><?php echo e($alternatif); ?></h1></strong>
                                                                Jumlah Data Alternatif Default
                                                            </div>
                                                            <div class="col-md-3">
                                                                <span class="fa fa-book fa-5x"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-footer">
                                                        <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
        
                            <?php if(Auth::user()->level_user == "Admin"): ?>
                            <div class="col-md-4">
                                <a href="<?php echo e(url('view/pengguna')); ?>">
                                    <div class="card bg-danger-400">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <strong><h1><?php echo e($calonSiswa); ?></h1></strong>
                                                    Jumlah Data Calon Siswa
                                                </div>
                                                <div class="col-md-3">
                                                    <span class="fa fa-user fa-5x"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
        
                    
                    <div class="container">
                        <div class="modal fade" id="profil<?php echo e(Auth::user()->id); ?>" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Update Profil</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal-body">
                                            <form action="/update/user/<?php echo e($user->id); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label for="nama" class="control-label">Nama</label>
                                                    <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($user->level_user == 'Admin' ? $user->admin['nama_admin'] :  $user->calonSiswa['nama_calonSiswa']); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="email" class="control-label">Email</label>
                                                    <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="alamat" class="control-label">Alamat</label>
                                                    <input type="text" name="alamat" id="alamat" class="form-control" value="<?php echo e($user->level_user == 'Admin' ? $user->admin['alamat_admin'] :  $user->calonSiswa['alamat_calonSiswa']); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="telp" class="control-label">Telp</label>
                                                    <input type="tel" name="telp" id="telp" class="form-control" value="<?php echo e($user->level_user == 'Admin' ? $user->admin['telp_admin'] :  $user->calonSiswa['telp_calonSiswa']); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="jenisKelamin" class="control-label">Jenis Kelamin</label>
                                                    <select name="jenisKelamin" id="jenisKelamin" class="form-control">
                                                        <option value="Laki - Laki" 
                                                            <?php if($user->level_user == 'Admin'): ?>
                                                                <?php if($user->admin['jenisKelamin_admin'] == 'Laki - Laki'): ?>
                                                                    selected
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($user->calonSiswa['jenisKelamin_calonSiswa'] == 'Laki - Laki'): ?>
                                                                    selected
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        >Laki - Laki</option>
                                                        <option value="Perempuan" 
                                                            <?php if($user->level_user == 'Admin'): ?>
                                                                <?php if($user->admin['jenisKelamin_admin'] == 'Perempuan'): ?>
                                                                    selected
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($user->calonSiswa['jenisKelamin_calonSiswa'] == 'Perempuan'): ?>
                                                                    selected
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        >Perempuan</option>
                                                    </select>
                                                </div>
                                                <hr>
                                                <div class="form-group">
                                                    <label for="oldPass">Password Lama</label>
                                                    <input type="password" name="oldPassword" class="form-control"placeholder="masukkan password lama">
                                                </div>
                                                <div class="form-group">
                                                    <label for="newPass">Password Baru</label>
                                                    <input type="password" name="password" class="form-control"placeholder="masukkan password baru">
                                                </div>
                                                <div class="form-group">
                                                    <label for="newPass">Konfirmasi Password Baru</label>
                                                    <input type="password" name="password_confirmation" class="form-control" placeholder="masukkan konfirmasi password">
                                                    <span class="mt-1 font-size-xs font-weight-semibold">* kosongkan password jika tidak ingin mengganti password</span>
                                                </div>
                                            </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-success btn-lg">Update</button>
                                            </form>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                </div>
                            </div>
                        </div>
                    </div>
                    
        
                    
                            
                        </div>
                    </div>
                        
                </div>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h1><strong>INFORMASI</strong></h1>
                        </div>
                    </div>
                    <div class="card-body">
                        <ol>
                            <li>Data Kriteria merupakan data yang digunakan sebagai acuan untuk penilaian terhadap alternatif</li>
                            <?php if(Auth::user()->level_user == 'Calon Siswa'): ?>
                                <li>Data alternatif siswa merupakan data alternatif yang dimiliki oleh siswa yang untuk dilakukan penilaian selain dapat menggunakan alternatif default yang terdapat pada sistem</li> 
                                <li>Data alternatif default merupakan data alternatif yang terdapat secara default pada sistem dan dapat digunakan sebagai alternatif default untuk dilakukan perhitungan jika tidak ingin menggunakan alternatif sendiri</li>
                            <?php endif; ?>
                            <?php if(Auth::user()->level_user == 'Admin'): ?>
                            <li>Data alternatif default merupakan data alternatif yang terdapat secara default pada sistem dan dapat digunakan sebagai alternatif default untuk dilakukan perhitungan</li>
                                <li>Data pengguna merupakan jumlah pengguna siswa yang terdaftar pada sistem</li>
                            <?php endif; ?>
                            </ol>
                    </div>
                </div>
            </div>

        </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\Fix\Example\resources\views/admin/index.blade.php ENDPATH**/ ?>