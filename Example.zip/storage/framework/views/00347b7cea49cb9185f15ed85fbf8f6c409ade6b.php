<?php $__env->startSection('pwd', 'Insert'); ?>
<?php $__env->startSection('now', 'Kriteria'); ?>
<?php $__env->startSection('insert', 'active'); ?>
<?php $__env->startSection('menu-insert-kriteria', 'nav-item-expanded nav-item-open'); ?>
<?php $__env->startSection('menu-insert', 'nav-item-expanded nav-item-open'); ?>
<?php $__env->startSection('link-active-insert-kriteria', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-2">
        <div class="card">
            <div class="card-header header-elements-inline">
                <h5 class="card-title">Form Input Kriteria</h5>
            </div>
            <div class="card-body">
                <form action="/kriteria" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                        <label for="kriteria" class="col-form-label col-lg-1">Kriteria</label>
                        <div class="col-lg-4">
                            <input type="text" name="nama_kriteria" class="form-control <?php if ($errors->has('nama_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_kriteria'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autofocus autocomplete="nama_kriteria" placeholder="masukkan nama kriteria">
                            <?php if ($errors->has('nama_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_kriteria'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tipe_kriteria" class="col-form-label col-lg-1">Tipe Kriteria</label>
                        <div class="col-lg-4">
                            <select name="tipe_kriteria" id="tipe_kriteria" class="form-control <?php if ($errors->has('tipe_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipe_kriteria'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                <option value="Benefit">Benefit</option>
                                <option value="Cost">Cost</option>
                            </select>
                            <?php if ($errors->has('nama_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_kriteria'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="bobot" class="col-form-label col-lg-1">Bobot</label>
                        <div class="col-lg-4">
                            <input type="number" class="form-control <?php if ($errors->has('bobot_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bobot_kriteria'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autofocus autocomplete="bobot_kriteria" placeholder="masukkan bobot kriteria" name="bobot_kriteria">
                            <?php if ($errors->has('bobot_kriteria')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bobot_kriteria'); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <div class="col-lg-1"></div>
                        <div class="col-lg-2">
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>


        
        
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\Example\resources\views/admin/insert/kriteria.blade.php ENDPATH**/ ?>