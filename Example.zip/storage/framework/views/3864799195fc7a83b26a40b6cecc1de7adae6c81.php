<?php $__env->startSection('pwd', 'Home'); ?>
<?php $__env->startSection('now', 'Dashboard'); ?>
<?php $__env->startSection('dashboard', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-2">
        <h1><strong>SELAMAT DATANG</strong></h1>

        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="<?php echo e(Auth::user()->level_user == "Admin" ? 'col-md-4' : 'col-md-4'); ?>">
                        <a href="<?php echo e(url('view/kriteria')); ?>">
                            <div class="card bg-indigo-400">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-9">
                                            <strong><h1><?php echo e($kriteria); ?></h1></strong>
                                            Jumlah Data Kriteria
                                        </div>
                                        <div class="col-md-3">
                                            <span class="fa fa-book-open fa-5x"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                </div>
                            </div>
                        </a>
                    </div>

                    <?php if(Auth::user()->level_user == "Admin"): ?>
                        <div class="<?php echo e(Auth::user()->level_user == "Admin" ? 'col-md-4' : 'col-md-6'); ?>">
                            <a href="<?php echo e(url('view/alternatif')); ?>">
                                <div class="card bg-green-400">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <strong><h1><?php echo e($alternatif); ?></h1></strong>
                                                Jumlah Data Alternatif Default
                                            </div>
                                            <div class="col-md-3">
                                                <span class="fa fa-book fa-5x"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php elseif(Auth::user()->level_user == "Calon Siswa"): ?>
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-6">
                                    <a href="<?php echo e(url('view/alternatif/user')); ?>">
                                        <div class="card bg-danger-400">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <strong><h1><?php echo e($countAlter); ?></h1></strong>
                                                        Jumlah Data Alternatif
                                                    </div>
                                                    <div class="col-md-3">
                                                        <span class="fa fa-book fa-5x"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                            </div>
                                        </div>
                                    </a>

                                </div>
                                <div class="col-md-6">
                                    <a href="<?php echo e(url('view/alternatif')); ?>">
                                        <div class="card bg-green-400">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <strong><h1><?php echo e($alternatif); ?></h1></strong>
                                                        Jumlah Data Alternatif Default
                                                    </div>
                                                    <div class="col-md-3">
                                                        <span class="fa fa-book fa-5x"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(Auth::user()->level_user == "Admin"): ?>
                    <div class="col-md-4">
                        <a href="<?php echo e(url('view/pengguna')); ?>">
                            <div class="card bg-danger-400">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-9">
                                            <strong><h1><?php echo e($calonSiswa); ?></h1></strong>
                                            Jumlah Data Calon Siswa
                                        </div>
                                        <div class="col-md-3">
                                            <span class="fa fa-user fa-5x"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <center><span class="fa fa-arrow-alt-circle-right"></span> Info lengkap</center>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            
                    
                </div>
            </div>
                
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\99%\90%\Example\resources\views/admin/index.blade.php ENDPATH**/ ?>