<?php $__env->startSection('pwd', 'view'); ?>

<?php $__env->startSection('now', 'Default Alter'); ?>

<?php $__env->startSection('link-active-view', 'active'); ?>
<?php $__env->startSection('link-active-alter', 'active'); ?>
<?php $__env->startSection('menu-view-alternatif', 'nav-item-expanded nav-item-open'); ?>
<?php $__env->startSection('menu-view', 'nav-item-expanded nav-item-open'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid mt-2">
        <div class="card">
            <div class="card-header header-elements-inline">
                <h5 class="card-title">Data Alternatif</h5>
            </div>
            
            <?php if(session('hapus')): ?>
                <?php echo $__env->make('../layouts/sweetalert/hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(session('update')): ?>
                <?php echo $__env->make('../layouts/sweetalert/update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(session('tambah')): ?>
                <?php echo $__env->make('../layouts/sweetalert/tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            
            <div class="card-body">
                <div class="row">
                        <div class="col-md-11"></div>
                        <div class="col-md-1">
                            <?php if(Auth::user()->level_user == 'Admin'): ?>
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#adddata">+ | Add Data</button>
                            <?php endif; ?>
                        </div>
                    </div>
                <table class="table table-bordered table-hover datatable-highlight">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Alternatif</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($alternatif['nama_alternatif']); ?></td>
                                <td class="text-center">
                                    <?php if(Auth::user()->level_user == 'Admin'): ?>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#updatedata<?php echo e($alternatif->id); ?>"><i class="fas fa-edit mr-3 fa-1x"></i>Ubah</button>
                                        <button class="btn btn-warning" data-toggle="modal" data-target="#deletedata<?php echo e($alternatif->id); ?>"><i class="fas fa-trash-alt mr-3 fa-1x"></i>Hapus</button>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $alternatif->nilai->where('user_id', Auth::user()->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    

                                    <?php if(count($alternatif->nilai->where('user_id', Auth::user()->id)) == 0): ?>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#nilai<?php echo e($alternatif->id); ?>"><i class="fas fa-edit mr-3 fa-1x"></i>Nilai</button>
                                    <?php else: ?>
                                        <?php if($alternatif['id'] == $nilai['alternatif_id']): ?>
                                        <?php echo e(Auth::user()->level_user == 'Admin' ? '|' : ''); ?> <span class="icon-checkmark-circle2 mr-3 icon-2x"></span>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#dataNilai<?php echo e($nilai->alternatif_id); ?>"><i class="fas fa-edit mr-3 fa-1x"></i>Nilai</button>
                                        <?php else: ?>
                                            <button class="btn btn-secondary" data-toggle="modal" data-target="#nilai<?php echo e($alternatif->id); ?>"><i class="fas fa-compass mr-3 fa-1x"></i>Nilai</button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    
                                </td>
                            </tr>

                            
                            <div class="container">
                                <div class="modal fade" id="updatedata<?php echo e($alternatif->id); ?>" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Update Alternatif</h4>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                        <div class="modal-body">
                                            <form action="/update/alternatif/<?php echo e($alternatif->id); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label for="nama_alternatif" class="control-label">Nama Alternatif</label>
                                                    <input type="text" name="nama_alternatif" id="nama_alternatif" class="form-control" value="<?php echo e($alternatif->nama_alternatif); ?>">
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-success btn-lg">Update</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                            

                            
                            <div class="modal fade" id="deletedata<?php echo e($alternatif->id); ?>" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Delete Alternatif</h4>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            
                                            <center><h2>Hapus Data ?</h1></center>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="/delete/alternatif/<?php echo e($alternatif->id); ?>">
                                                <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                <button type="button" class="btn btn-warning btn-lg">Hapus</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                            
                            <div class="modal fade" id="nilai<?php echo e($alternatif->id); ?>" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Tambah Alternatif</h4>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <form action="/evaluasi/store" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="modal-body">
                                                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $param = explode(" ", $item['nama_kriteria']);
                                                ?>
                                                    <input type="text" name="alternatif_id[]" value="<?php echo e($alternatif->id); ?>" hidden>

                                                    <div class="form-group">
                                                        <label><?php echo e($item['nama_kriteria']); ?></label>
                                                        <input type="text" name="kriteria_id[]" value="<?php echo e($item['id']); ?>" hidden>
                                                        <select name="nilai[]" class="form-control">
                                                            <option value="1">Buruk</option>
                                                            <option value="2">Sedang</option>
                                                            <option value="3">Baik</option>
                                                        </select>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-success btn-lg">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            

                            
                            <?php if(count($alternatif->nilai->where('user_id', Auth::user()->id)) > 0): ?>
                                <div class="container">
                                    <div class="modal fade" id="dataNilai<?php echo e($nilai->alternatif_id); ?>" role="dialog">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Update Data Nilai</h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>
                                            <div class="modal-body">
                                                <form action="/evaluasi/nilai/<?php echo e($alternatif->id); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <div class="form-group">
                                                            <label><?php echo e($krit['nama_kriteria']); ?></label>
                                                            <input type="text" name="kriteria_id[]" value="<?php echo e($krit['id']); ?>" hidden>

                                                            <?php $__currentLoopData = $krit->nilai->where('alternatif_id', $alternatif['id'])->where('user_id', Auth::user()->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <select name="nilai[]" class="form-control">
                                                                    <option value="1" <?php echo e($nilai['nilai'] == '1' ? 'selected' : ''); ?>>Buruk</option>
                                                                    <option value="2" <?php echo e($nilai['nilai'] == '2' ? 'selected' : ''); ?>>Sedang</option>
                                                                    <option value="3" <?php echo e($nilai['nilai'] == '3' ? 'selected' : ''); ?>>Baik</option>
                                                                </select>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-success btn-lg">Update</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                    
                    <div class="modal fade" id="adddata" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Tambah Alternatif</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <form action="/alternatif" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="nama_alternayif">Nama Alternatif</label>
                                            <input type="text" class="form-control" name="nama_alternatif" id="nama_alternatif" required autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-success btn-lg">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    

                    
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Kelas\Semester 7\Tugas Akhir 2\backup\99%\90%\Example\resources\views/admin/view/defaultAlter.blade.php ENDPATH**/ ?>